the SMF.php goes in the drivers folder, and the _config.smf is a sample of _config.php that I am using.

matt.h@gmx.com