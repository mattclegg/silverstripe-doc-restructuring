<?php
/**
 * SMF Forurm driver for authentication
 * The SSTRIPE.php driver was used as a starting point for this (although almost no code from that remains.
 * It uses MySQL to access the SMF database directly
 *
 * @author Matt Hardwick <matt.h@gmx.com>
 *
 * @version 1.2
 */
 
class SMF_Authenticator {

    /**
     * Tries to logon using the credentials in the SMF database
     *
     * @access public
     *
     * @param  string $source Authentication source to be used 
     * @param  string $external_uid    The ID entered
     * @param  string $external_passwd The password of the user
     *
     * @return array  $SS_details 	   Contains firstname, surname and email address
	 *                                 returns false if the authentication fails.
	 *
	 */
	 
    public function Authenticate($source, $external_uid, $external_passwd) {

	
$SMF_Location = ExternalAuthenticator::getOption($source,'smfPath');
// don't edit this stuff, unless you've changed the name of SSI.php or the Sources folder!
// they are included to provide settings about SMF, it's database and the correct encryption mentod
include_once($SMF_Location . "SSI.php");
include_once($SMF_Location . "Sources/Subs-Auth.php");
	
		// cut any rubbish out of what was entered.
        $SMF_SQLSafe_uid = Convert::raw2sql($external_uid);
		$SMF_SQLSafe_passwd = Convert::raw2sql($external_passwd);
		
		//encrypt the password to SMF style
		$SMF_SQLSafe_passwd = sha1(strtolower($SMF_SQLSafe_uid) . un_htmlspecialchars(stripslashes($SMF_SQLSafe_passwd)));

		// create the MySQL connection and use settings from Settings.php to connect to the database
		$SMF_DBConnection = mysql_pconnect($db_server, $db_user, $db_passwd) or trigger_error(mysql_error(),E_USER_ERROR);
		$SMF_MemberTable = "" . $db_prefix . "members";		
		$SMF_SQLString = "SELECT realName, emailAddress FROM " . $SMF_MemberTable . " WHERE memberName='" . $SMF_SQLSafe_uid . "' AND passwd='" . $SMF_SQLSafe_passwd . "'";
		
		mysql_select_db($dbname, $SMF_DBConnection);
		$SMF_Query = mysql_query($SMF_SQLString, $SMF_DBConnection) or die(mysql_error());
	    $SMF_FoundUser = mysql_num_rows($SMF_Query);

        if ($SMF_FoundUser) {
            
			$SMF_Name_preSplit  = mysql_result($SMF_Query,0,'realName');
			$SMF_EmailAddress  = mysql_result($SMF_Query,0,'emailAddress');
			
			list($SS_details['firstname'], $SS_details['surname']) = explode(" ", $SMF_Name_preSplit, 2);
			$SS_details['email'] = $SMF_EmailAddress;
			echo $SS_details;
			return $SS_details;
			
        } else {
            ExternalAuthenticator::setAuthMessage(_t('ExternalAuthenticator.Failed'));
            return false;
        }
    }
}
        

