<?php

class Page extends SiteTree {
	static $db = array(
	);
	static $has_one = array(
   );
	static $has_many = array(
		'Quotes' => 'Quote'
	);
	function getCMSFields() {
		$fields = parent::getCMSFields();
		$tablefield = new HasManyComplexTableField(
			$this,
			'Quotes',
		    'Quote',
		    array(
			    'Author' => 'Author',
			    'QuoteText' => 'Quote Text'
		    ),
		    'getCMSFields_forPopup'
		);
		$tablefield->setAddTitle( 'A Quote' );

		$fields->addFieldToTab( 'Root.Content.Quotes', $tablefield );
		return $fields;
}
}

class Page_Controller extends ContentController {
	function init() {
		parent::init();
		Requirements::themedCSS("layout");
		Requirements::themedCSS("typography");
		Requirements::themedCSS("form");
	}
}

?>