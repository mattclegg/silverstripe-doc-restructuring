<?php

class Quote extends DataObject {
	
	static $db = array(
		'Author' => 'Varchar(200)',
		'QuoteText' => 'Varchar(255)'
	);
	static $has_one = array(
		'Page' => 'Page'
	);
	
	function getCMSFields_forPopup() {
		return new FieldSet(
			new TextField('Author'),
			new TextareaField('QuoteText')
		);
	}
}
?>