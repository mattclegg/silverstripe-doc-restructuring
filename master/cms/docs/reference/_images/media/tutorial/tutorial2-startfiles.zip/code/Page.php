<?

class Page extends SiteTree {
	static $db = array(
	);
	
	static $defaults = array(
	);

	
}

class Page_Controller extends ContentController {

}

?>
