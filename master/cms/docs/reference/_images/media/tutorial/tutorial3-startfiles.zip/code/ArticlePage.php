<?php

/**
 * Defines the ArticlePage page type
 */
class ArticlePage extends Page {
	static $db = array(
		'Date' => 'Date',
		'Author' => 'Text'
	);
	static $has_one = array(
	);
	static $defaults = array(
		'ProvideComments' => true
	);
	static $icon = "mysite/images/treeicons/news";
	
	function getCMSFields() {
		$fields = parent::getCMSFields();
		
		$fields->addFieldToTab('Root.Content.Main', new CalendarDateField('Date'), 'Content');
		$fields->addFieldToTab('Root.Content.Main', new TextField('Author'), 'Content');
		
		return $fields;
	}
}
 
class ArticlePage_Controller extends Page_Controller {
 
}

?>
